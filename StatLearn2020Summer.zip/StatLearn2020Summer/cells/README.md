The foloder "cells" keep the documents on terms.
Each cell file should handle one topic with a focus on either one of categories i.e., "genetics/omics", "statistics", "machine learning", "mathematics", and "computer skills".
Cell files handling one of the categories may require topics of the other categories but the details on them should be avoided and the details should be linked to independent cells, so that the readers should be able to focus on the category of the cell file.
