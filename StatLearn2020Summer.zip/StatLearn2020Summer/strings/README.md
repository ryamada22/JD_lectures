The folder "strings" keeps files that connect multiple cell documents as lecture courses should proceed.
The string files should have an introductory statement on the top and connect multiple cell files with explanations between them,
so that the string courses behave meaningful on their own.
